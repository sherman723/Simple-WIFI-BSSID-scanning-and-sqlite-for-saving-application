package com.abc.wifibssid;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListDataActivity extends AppCompatActivity {
    private static final String TAG = "ListDataActivity";
    DatabaseHelper mDatabaseHelper;
    private ListView mListView;
    TextView database;

    protected void OnCreate(@Nullable Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
        database = (TextView)findViewById(R.id.database);
        TM("YO baby");
        //mListView = (ListView) findViewById(R.id.listView);
        mDatabaseHelper = new DatabaseHelper(this);
        populateListView();

    }

    private void populateListView() {
        Log.d(TAG, "populateListView:  Displaying data in the ListView.");

        Cursor data = mDatabaseHelper.getData();
        ArrayList<String> listData = new ArrayList<>();
        //database.setText("hi");
      while(data.moveToNext())
        {
            listData.add(data.getString(1));

        }
        ListAdapter adapter = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1 , listData);
        mListView.setAdapter(adapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String name = adapterView.getItemAtPosition(i).toString();
                Log.d(TAG , "onItemClick: You Clicked on " + name);

                Cursor data = mDatabaseHelper.getItemID(name);
                TM(String.valueOf(data.getInt(0)));
                int itemID =-1;
                while(data.moveToNext())
                {
                    itemID = data.getInt(0);

                }
                if(itemID > -1 )
                {
                    Log.d(TAG, "onItemClick: The ID is :  "+ itemID);
                    TM(String.valueOf(itemID));

                }
                else
                        TM("No ID associated with that name");

            }
        });

    }
    public void TM(String message)
    {
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }


}
