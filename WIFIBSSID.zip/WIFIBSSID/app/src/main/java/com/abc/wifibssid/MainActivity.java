package com.abc.wifibssid;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.location.Location;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import android.support.annotation.NonNull;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class MainActivity extends AppCompatActivity implements ConnectionCallbacks,OnConnectionFailedListener{
    public static final int RequestPermissionCode = 1;
    private GoogleApiClient gac;
    private FusedLocationProviderClient fl;
    private WifiManager wifiManager;
    private ListView wifiList;
    ListAdapter listAdapter;
    List mywifiList;
    List<ScanResult> list;
    DatabaseHelper mDatabaseHelper;
    long currenttime;
    long x;
    StringBuilder mylocation;
    private int size = 0;
    private List<ScanResult> results;
    private ArrayList<String>arrayList = new ArrayList<>();
    private ArrayAdapter adapter;
    EditText durans;
    Button open;
    Button save;
    Button email;
    TextView location;
    WifiReceiver wifiReceiver;
StringBuilder sb;




    CountDownTimer realtimer;


    @SuppressLint("WifiManagerLeak")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        location = (TextView)findViewById(R.id.location);
        Button sent = (Button) findViewById(R.id.sent);
         durans = (EditText) findViewById(R.id.durans);
         mDatabaseHelper = new DatabaseHelper(this);
         open = (Button)findViewById(R.id.open);
         save = (Button)findViewById(R.id.save);
         email = (Button) findViewById(R.id.email);



         email.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 String[] TO = {"sherman98723@gmail.com"};

                 Intent emailIntent = new Intent (Intent.ACTION_SEND);
                 emailIntent.setData(Uri.parse("mailto:"));
                 emailIntent.setType("text/plain");
                 emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                 emailIntent.putExtra(Intent.EXTRA_SUBJECT," Testing app see see can run or not");
             emailIntent.putExtra(Intent.EXTRA_TEXT, sb.toString());
             startActivity(Intent.createChooser(emailIntent,"Sending email....."));



             }
         });


         save.setOnClickListener(new View.OnClickListener()
         {
             public void onClick(View v)
             {
                 String newEntry = sb.toString();

                 if(newEntry.length()> 0) {

                     AddData(newEntry);
                 }

             }
         });

       open.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
               Intent intent = new Intent (MainActivity.this, openview.class);

               startActivity(intent);
            }
        });





wifiManager = (WifiManager) this.getSystemService(Context.WIFI_SERVICE);
wifiList = (ListView)findViewById(R.id.wifiList);


        register();
        WifiReceiver wifiReceiver = new WifiReceiver();


   scanWifi();
sent.setOnClickListener(new View.OnClickListener(){
        public void onClick(View v) {
            if(!(durans.getText().toString().equals(""))&&(TextUtils.isDigitsOnly(durans.getText()))) {
                x = Integer.parseInt(durans.getText().toString()) * 1000;
                Toast.makeText(MainActivity.this, "Starting Wifi Scanning every " + x / 1000 + " seconds", Toast.LENGTH_LONG).show();
                durans.setText("");

                    realtimer = new CountDownTimer(x, 1000) {
                        @Override

                        public void onTick(long l) {

                        }


                        public void onFinish() {
                            if (currenttime < 1000) {
TM("Scanning wifi");
                                scanWifi();
                            }

                        }

                    }.start();

            }
            else
            {
                TM("Please input the duration");
            }


        }
        });





    }




public void AddData(String newEntry)
{
    boolean insertData = mDatabaseHelper.addData(newEntry);
    if(insertData)
        TM("Data Successfully Saved!");
        else
            TM("Data is not saved..... Please try  again");

}
private void TM (String message)
{
    Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
}
public void scanWifi()
{
    if(wifiManager.isWifiEnabled())
    {
     //   registerReceiver(wifiReceiver,new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
      list = wifiManager.getScanResults();
        sb= new StringBuilder();
        Cursor data = mDatabaseHelper.getData();
        ArrayList<String> listData = new ArrayList<>();






        for(ScanResult scanResult: list)
        {
            listData.add("SSID is : "+scanResult.SSID+"\n"+"BSSID is : "+scanResult.BSSID+"\n");
            sb.append("SSID is : "+scanResult.SSID+"\n"+"BSSID is : "+scanResult.BSSID+"\n");


        }
       // listData.add(sb.toString());
        ListAdapter adapter = new ArrayAdapter<String>(this , android.R.layout.simple_list_item_1 , listData);
        wifiList.setAdapter(adapter);
    }
    else
        TM("Please turn on WIFI");
}

protected void onPause()
{

    gac.disconnect();
    //unregisterReceiver(wifiReceiver);
    super.onPause();
}

    protected void onReume()
    {

        gac.connect();
 //  registerReceiver(wifiReceiver , new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        super.onResume();
    }






    public void register()
    {
    gac = new GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
    fl=LocationServices.getFusedLocationProviderClient(this);
    location = (TextView) findViewById(R.id.location);
    }
    public void onStart()
    {
        super.onStart();
        gac.connect();
    }

    public void onStop()
    {
        if(gac.isConnected())
        {
            gac.disconnect();
        }
        super.onStop();
    }
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
    {
        Log.e("MainActivity","Connection failed: "+connectionResult.getErrorCode());
    }
    public void onConnectionSuspended(int i)
    {
        Log.e("MainActivity","Connection suspended");
    }

    public void onConnected(@Nullable Bundle bundle)
    {
        if(ActivityCompat.checkSelfPermission(this,ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED)
        {
            requestPermission();
        }
        else{
        fl.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location x) {
                if (x != null) {
                    mylocation = new StringBuilder();
                    mylocation.append("Current Latitude is: ");
                    mylocation.append(x.getLatitude());
                    mylocation.append("\n");
                    mylocation.append("Curent Longitude is ");
                    mylocation.append(x.getLongitude());

                    location.setText(mylocation);


                }
            }
        });
    }
    }
class WifiReceiver extends BroadcastReceiver
{

    @Override
    public void onReceive(Context context, Intent intent) {
        if(wifiManager.isWifiEnabled())
        {
            list = wifiManager.getScanResults();
            sb= new StringBuilder();
            Cursor data = mDatabaseHelper.getData();
            ArrayList<String> listData = new ArrayList<>();

    TM(" working....");




            for(ScanResult scanResult: list)
            {
                listData.add("SSID is : "+scanResult.SSID+"\n"+"BSSID is : "+scanResult.BSSID+"\n");
                sb.append("SSID is : "+scanResult.SSID+"\n"+"BSSID is : "+scanResult.BSSID+"\n");


            }
            // listData.add(sb.toString());
            ListAdapter adapter = new ArrayAdapter<String>(MainActivity.this , android.R.layout.simple_list_item_1 , listData);
            wifiList.setAdapter(adapter);
        }
        else
            TM("Please turn on WIFI");

    }
}
    public void requestPermission(){
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{ACCESS_FINE_LOCATION},RequestPermissionCode);
    }
}
